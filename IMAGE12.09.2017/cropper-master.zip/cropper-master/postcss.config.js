module.exports = {
  plugins: {
    'postcss-cssnext': {},
    'postcss-url': {
      url: 'inline',
    },
  },
};
