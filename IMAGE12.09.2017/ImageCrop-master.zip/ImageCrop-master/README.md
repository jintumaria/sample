ImageCrop
=========
sample code for http://riddhimajava.blogspot.in/2014/06/javajquery-crop-image.html
